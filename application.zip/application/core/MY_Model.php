<?php 
/* -*- tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MY_Model extends CI_Model {
	
	function __construct() {
		parent::__construct();
	}
}

/* End of file MY_Model.php */
/* Location: ./application/models/MY_Model.php */