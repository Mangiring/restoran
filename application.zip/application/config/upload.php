<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['sfile']['catalog'] = 'sfile/catalog/';
$config['sfile']['arsip'] = 'sfile/arsip/';
$config['sfile']['cover'] = 'sfile/cover/';
